# 🧠 Social Media Content Creator

Ein einfaches KI-Tool, das automatisch Social-Media-Beiträge erstellt (inkl. Hashtags & Emojis).

## 🚀 Funktionen
- Eingabe von Thema, Tonfall & Plattform
- KI-generierter Text mit Hashtags und Emojis
- Einfache Weboberfläche mit Tailwind CSS

## 🛠️ Installation (in Replit)
1. Neues Replit-Projekt erstellen (Python + Flask)
2. Dateien wie oben hinzufügen
3. In der Shell ausführen:
   pip install -r requirements.txt
4. OpenAI API Key als Secret hinzufügen:
   - In Replit → "🔑 Secrets"
   - Key: OPENAI_API_KEY
   - Value: dein OpenAI-API-Schlüssel
5. Projekt starten → Browser zeigt die App an

## 💬 Beispiel
**Thema:** Kundengewinnung mit Webseiten  
**Tonfall:** Motivational  
**Plattform:** LinkedIn

➡️ Beispielausgabe:
> 🚀 Deine Website ist mehr als Design – sie ist dein 24/7-Verkäufer!  
> 💡 Nutze klare Botschaften und echten Mehrwert, um Kunden zu gewinnen.  
> #Webdesign #Marketing #DigitaleMedien