from flask import Flask, render_template, request
import openai
import os

app = Flask(__name__)
openai.api_key = os.getenv("OPENAI_API_KEY")

@app.route("/", methods=["GET", "POST"])
def index():
    content = ""
    if request.method == "POST":
        topic = request.form["topic"]
        tone = request.form["tone"]
        platform = request.form["platform"]

        prompt = f"Schreibe einen {tone} Social-Media-Post für {platform} zum Thema '{topic}'. Füge passende Emojis und Hashtags hinzu."

        response = openai.Completion.create(
            model="text-davinci-003",
            prompt=prompt,
            max_tokens=200,
            temperature=0.8
        )

        content = response.choices[0].text.strip()

    return render_template("index.html", content=content)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=81)